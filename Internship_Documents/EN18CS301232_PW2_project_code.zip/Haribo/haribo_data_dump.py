import pandas as pd
import warnings
import sys
warnings.filterwarnings('ignore')


def get_kpi_score(project_id, date):
    tagged_df = pd.read_csv('Haribo/input_data.csv')
    tagged_df = tagged_df[(tagged_df['class_name'] != "Others") & (tagged_df['class_name'] != "Candy_Others")]
    tagged_df['facings'] = tagged_df.groupby(['shop_id', 'shop_name', 'class_name'])['class_name'].transform('count')
    tagged_df['image_url'] = 'https://view.shelfwatch.io/?url=' + tagged_df['gcs_file_path']
    tagged_df['width'] = round((tagged_df['x_max'] - tagged_df['x_min']), 2)
    for (shop_id), df in tagged_df.groupby(['shop_id']):
        kpi = 1
        factor = 1.25
        x = df['width'].min()
        '''
            sos of self / (self + trolli)
            sos of self / (self + competitors)
        '''
        while len(df) > 0:
            # print(f'Factor : {factor}, KPI_Score : {kpi}')
            tagged_df.at[df[df['width'] <= (x * factor)].index, 'kpi_score'] = kpi
            tagged_df.at[df[df['width'] <= (x * factor)].index, 'mininum_x'] = x
            tagged_df.at[df[df['width'] <= (x * factor)].index, 'factor'] = factor
            tagged_df.at[df[df['width'] <= (x * factor)].index, 'maximum_length_allowed'] = factor*x
            df = df[df['width'] > (x * factor)]
            factor += 0.5
            kpi += 0.2
    records = []
    for (shop_id, shop_name), df in tagged_df.groupby(['shop_id', 'shop_name']):
        print(shop_id, shop_name)
        self_space = df[df['competition'] == 'self']['kpi_score'].sum()
        competitor_space = df[df['competition'] == 'competitor']['kpi_score'].sum()
        trolli_space = df[df['class_name'] == 'TROLLI']['kpi_score'].sum()
        trolli_competitor_space = df[df['class_name'] != 'TROLLI']['kpi_score'].sum()
        sos_haribo_competitor = round(self_space / (self_space + competitor_space), 2)
        sos_haribo_trolli = round(self_space / (self_space + trolli_space), 2)
        sos_competitor = round(competitor_space / (self_space + competitor_space), 2)
        sos_trolli = round(trolli_space / (self_space + trolli_space), 2)
        sos_trolli_competitor = round(trolli_space / (trolli_space + trolli_competitor_space), 2)
        for image_url in df['image_url'].unique():
            records.append({'date': date, 'shop_id': shop_id, 'shop_name': shop_name, 'image_url': image_url, 'sos_haribo_against_trolli': sos_haribo_trolli,
                            'sos_haribo_against_competitor': sos_haribo_competitor, 'sos_trolli': sos_trolli, 
                            'sos_trolli_against_competitor': sos_trolli_competitor, 'sos_competitor': sos_competitor})

    print('Unique KPI Scores :', sorted(tagged_df['kpi_score'].unique().tolist()))
    print(tagged_df.columns.tolist())
    result_df = pd.DataFrame(records)
    result_df.to_csv('Haribo/result_df.csv', index=False)
    qc_df = tagged_df[['shop_id', 'shop_name', 'image_url', 'class_name', 'competition', 'width', 
        'mininum_x', 'factor', 'maximum_length_allowed', 'kpi_score']]
    qc_df.to_csv('Haribo/qc_df.csv', index=False)

    facing_df = tagged_df[['shop_id', 'shop_name', 'class_name', 'facings']].drop_duplicates(['shop_name', 'class_name'])
    facing_df.to_csv('Haribo/facings_df.csv')


project_id = 468
date = '2022-02-24'
get_kpi_score(project_id, date)
